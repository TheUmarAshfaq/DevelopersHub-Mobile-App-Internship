The project files are too large to be hosted directly on GitHub due to repository size limitations.

Therefore, the complete dataset / project ZIP file has been uploaded to Google Drive.

You can access the full project here:
https://drive.google.com/drive/folders/1JU5QRY5cKK4TTO9xn7GmADjUmqpWAQ4W?usp=drive_link